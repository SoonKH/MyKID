package com.mykid.RoomHelper;

import android.content.Context;

import androidx.room.Room;

public class Kid {

    Context context;
    private static Kid instance;

    private NotesDatabase notesDatabase;

    public Kid(Context context){
        this.context = context;

        notesDatabase = Room.databaseBuilder(context,NotesDatabase.class,"ActivityAppDatabase").build();
    }

    public static synchronized Kid getInstance(Context context){
        if (instance==null){
            instance = new Kid(context);
        }
        return instance;
    }

    public NotesDatabase getNotesDatabase(){
        return notesDatabase;
    }
}

