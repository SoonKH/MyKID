package com.mykid.RoomHelper;

import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

import java.io.Serializable;

@Entity
public class NotesPojo implements Serializable {

    @PrimaryKey(autoGenerate = true)
    private int id;

    @ColumnInfo(name = "title")//Activity
    private String title;

    @ColumnInfo(name = "dateandtime")
    private String dateandtime;

    @ColumnInfo(name = "location")// Location
    private String location;

    @ColumnInfo(name = "description")//Report
    private String description;

    @ColumnInfo(typeAffinity = ColumnInfo.BLOB) // Byte will become a BLOB type of the field inside our database
    byte [] image;

    public int getId(){
        return id;
    }

    public void setId(int id){
        this.id=id;
    }

    public String getTitle(){
        return title;
    }

    public void setTitle(String title){
        this.title=title;
    }

    public String getDateandtime(){
        return dateandtime;
    }

    public void setDateandtime(String dateandtime){ this.dateandtime=dateandtime; }

    public String getLocation(){
        return location;
    }

    public void setLocation(String location){
        this.location = location;
    }

    public String getDescription(){
        return description;
    }

    public void setDescription(String description){
        this.description = description;
    }

    public byte[] getImage() {
        return image;
    }

    public void setImage(byte[] image) {
        this.image = image;
    }

}

