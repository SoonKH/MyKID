package com.mykid.RoomHelper;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import java.util.List;

@Dao
public interface NotesDAO {

    @Query("SELECT * FROM notespojo ORDER BY title ASC") //ASC is the short form for ascending
    List<NotesPojo> getAll();

    @Query("SELECT * FROM notespojo WHERE title LIKE :search  ORDER BY title ASC")
    List<NotesPojo> getFilter(String search);

    @Insert
    void insert(NotesPojo notesPojo);

    @Update
    void update(NotesPojo notesPojo);

    @Delete
    void delete(NotesPojo notesPojo);
}
