package com.mykid.Adapter;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Filter;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.mykid.R;
import com.mykid.RoomHelper.NotesDatabaseHelper;
import com.mykid.RoomHelper.NotesPojo;
import com.mykid.UpdateActivity;

import java.util.ArrayList;
import java.util.List;

public class NotesAdapter extends RecyclerView.Adapter<NotesAdapter.ViewHolder> {

    Context context;
    List<NotesPojo> activity_list;

    public NotesAdapter(Context context){
        this.context = context;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.rv_item_layout,parent,false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        holder.activity_tv.setText(activity_list.get(position).getTitle());
        holder.location_tv.setText(activity_list.get(position).getLocation());
        holder.dateandtime_tv.setText(activity_list.get(position).getDateandtime());
        holder.report_tv.setText(activity_list.get(position).getDescription());
        holder.card_view.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(context, UpdateActivity.class);
                intent.putExtra("activity_tables",activity_list.get(position));
                context.startActivity(intent);
            }
        });
    }

    @Override
    public int getItemCount() {
        return activity_list.size();
    }

    public void addActivity(List<NotesPojo> notesPojos) {
        this.activity_list = notesPojos;
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView activity_tv,location_tv,dateandtime_tv,report_tv;
        CardView card_view;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            activity_tv = itemView.findViewById(R.id.activity_tv);
            location_tv = itemView.findViewById(R.id.location_tv);
            dateandtime_tv = itemView.findViewById(R.id.dateandtime_tv);
            report_tv = itemView.findViewById(R.id.report_tv);
            card_view = itemView.findViewById(R.id.card_view);
        }
    }
}
