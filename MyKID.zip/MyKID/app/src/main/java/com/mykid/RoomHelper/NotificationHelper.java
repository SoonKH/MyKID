package com.mykid.RoomHelper;

import android.annotation.TargetApi;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Context;
import android.content.ContextWrapper;
import android.os.Build;

import androidx.core.app.NotificationCompat;

import com.mykid.R;

public class NotificationHelper extends ContextWrapper {
    public static final String notification1ID = "notification1ID";
    public static final String notification1Name = "notification1Name";
    public static final String notification2ID = "notification2ID";
    public static final String notification2Name = "notification12Name";

    private NotificationManager mManager;

    public NotificationHelper(Context base) {
        super(base);
        if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            createNotification();
        }
    }

    @TargetApi(Build.VERSION_CODES.O)
    public void createNotification(){
        NotificationChannel channel1 = new NotificationChannel(notification1ID,notification1Name, NotificationManager.IMPORTANCE_DEFAULT);
        channel1.enableLights(true);
        channel1.enableVibration(true);
        channel1.setLightColor(R.color.design_default_color_primary);
        channel1.setLockscreenVisibility(Notification.VISIBILITY_PRIVATE);

        getManager().createNotificationChannel(channel1);

        NotificationChannel channel2 = new NotificationChannel(notification2ID,notification2Name, NotificationManager.IMPORTANCE_DEFAULT);
        channel2.enableLights(true);
        channel2.enableVibration(true);
        channel2.setLightColor(R.color.design_default_color_primary);
        channel2.setLockscreenVisibility(Notification.VISIBILITY_PRIVATE);

        getManager().createNotificationChannel(channel2);
    }
    public NotificationManager getManager(){
        if(mManager == null){
            mManager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        }
        return mManager;
    }

    public NotificationCompat.Builder getChannel1Notification(String activity, String dateandtime){
        return new NotificationCompat.Builder(getApplicationContext(),notification1ID)
                .setContentTitle(activity)
                .setContentText(dateandtime)
                .setSmallIcon(R.drawable.add_activity_icon);
    }

    public NotificationCompat.Builder getChannel2Notification(String activity, String dateandtime){
        return new NotificationCompat.Builder(getApplicationContext(),notification2ID)
                .setContentTitle(activity)
                .setContentText(dateandtime)
                .setSmallIcon(R.drawable.save_icon);
    }
}
