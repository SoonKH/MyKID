package com.mykid.RoomHelper;

import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.widget.Toast;

import androidx.recyclerview.widget.RecyclerView;
import androidx.room.Delete;

import com.mykid.Adapter.NotesAdapter;
import com.mykid.DashboardActivity;

import java.util.List;

public class NotesDatabaseHelper {

    Context context;
    NotesAdapter notesAdapter;

    public NotesDatabaseHelper(Context context){
        this.context = context;

        notesAdapter = new NotesAdapter(context);
    }

    public void addActivity(String activity, String report, String location, String dateandtime, byte[] image){
        class AddActivity extends AsyncTask<Void,Void,NotesPojo>{

            @Override
            protected NotesPojo doInBackground(Void... voids) {
                NotesPojo notesPojo = new NotesPojo();
                notesPojo.setTitle(activity);
                notesPojo.setLocation(location);
                notesPojo.setDateandtime(dateandtime);
                notesPojo.setDescription(report);
                notesPojo.setImage(image);

                Kid.getInstance(context)
                        .getNotesDatabase()
                        .notesDAO()
                        .insert(notesPojo);

                return notesPojo;
            }

            @Override
            protected void onPostExecute(NotesPojo notesPojo) {
                super.onPostExecute(notesPojo);
                if(notesPojo != null){
                    Intent intent = new Intent(context, DashboardActivity.class);
                    intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
                    context.startActivity(intent);
                    Toast.makeText(context,"Activity Saved",Toast.LENGTH_SHORT).show();
                }else{
                    return;
                }

            }
        }

        AddActivity addActivity = new AddActivity();
        addActivity.execute();
    }

    //get data from database
    public void getAllActivity(RecyclerView recyclerView){
        class GetALlActivity extends AsyncTask<Void,Void, List<NotesPojo>>{

            @Override
            protected List<NotesPojo> doInBackground(Void... voids) {
                List<NotesPojo> notes_list = Kid
                        .getInstance(context)
                        .getNotesDatabase()
                        .notesDAO()
                        .getAll();
                return notes_list;
            }

            @Override
            protected void onPostExecute(List<NotesPojo> notesPojos) {
                super.onPostExecute(notesPojos);

                if(notesPojos != null && notesPojos.size()>0){
                    notesAdapter.addActivity(notesPojos);
                    recyclerView.setAdapter(notesAdapter);
                }
            }
        }

        GetALlActivity aLlActivity = new GetALlActivity();
        aLlActivity.execute();
    }

    public void filterActivity(RecyclerView recyclerView, String search){
        class filterActivity extends AsyncTask<Void,Void, List<NotesPojo>>{

            @Override
            protected List<NotesPojo> doInBackground(Void... voids) {
                List<NotesPojo> notes_list = Kid
                        .getInstance(context)
                        .getNotesDatabase()
                        .notesDAO()
                        .getFilter(search);
                return notes_list;
            }

            @Override
            protected void onPostExecute(List<NotesPojo> notesPojos) {
                super.onPostExecute(notesPojos);

                if(notesPojos != null && notesPojos.size()>0){
                    notesAdapter.addActivity(notesPojos);
                    recyclerView.setAdapter(notesAdapter);
                }
            }
        }

        filterActivity filterActivity = new filterActivity();
        filterActivity.execute();
    }

    public void updateActivity(NotesPojo notesPojo, String activity, String report, String location, String dateandtime, byte[] image){
        class UpdateActivity extends AsyncTask<Void,Void,Void>{

            @Override
            protected Void doInBackground(Void... voids) {
                notesPojo.setTitle(activity);
                notesPojo.setDescription(report);
                notesPojo.setLocation(location);
                notesPojo.setDateandtime(dateandtime);
                notesPojo.setImage(image);

                Kid.getInstance(context)
                        .getNotesDatabase()
                        .notesDAO()
                        .update(notesPojo);
                return null;
            }

            @Override
            protected void onPostExecute(Void aVoid) {
                super.onPostExecute(aVoid);

                if(notesPojo != null){
                    Intent intent = new Intent(context,DashboardActivity.class);
                    intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
                    context.startActivity(intent);

                    Toast.makeText(context, "Activity Updated", Toast.LENGTH_SHORT).show();
                }else{
                    return;
                }
            }
        }
        UpdateActivity updateActivity = new UpdateActivity();
        updateActivity.execute();
    }

    public void deleteActivity(NotesPojo notesPojo){
        class DeleteActivity extends AsyncTask<Void,Void,Void>{

            @Override
            protected Void doInBackground(Void... voids) {
                Kid.getInstance(context)
                        .getNotesDatabase()
                        .notesDAO()
                        .delete(notesPojo);

                return null;
            }

            @Override
            protected void onPostExecute(Void aVoid) {
                super.onPostExecute(aVoid);

                Intent intent = new Intent(context,DashboardActivity.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
                context.startActivity(intent);
            }
        }

        DeleteActivity deleteActivity = new DeleteActivity();
        deleteActivity.execute();
    }
}
