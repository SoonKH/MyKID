package com.mykid;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NotificationCompat;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.text.Editable;
import android.text.InputType;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TimePicker;
import android.widget.Toast;

import java.io.ByteArrayOutputStream;
import java.text.SimpleDateFormat;

import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.MapView;
import com.google.android.gms.tasks.OnSuccessListener;
import com.mykid.RoomHelper.MapsActivity;
import com.mykid.RoomHelper.NotesDatabaseHelper;
import com.mykid.RoomHelper.NotificationHelper;

import java.util.Calendar;
import java.util.List;
import java.util.Locale;

public class AddActivity extends AppCompatActivity {

    EditText title_activity,title_location,title_dateandtime,title_report;
    NotesDatabaseHelper database_helper;
    Button btn;
    Button takePhoto;
    ImageView img;
    Bitmap pic;
   // MapView map;

    private FusedLocationProviderClient fusedLocationProviderClient;
    private NotificationHelper mNotificationHelper;
    @SuppressLint("RestrictedApi")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setTitle("Add New Activity");

        title_activity = findViewById(R.id.title_activity);
        title_location = findViewById(R.id.title_location);
        title_dateandtime = findViewById(R.id.title_dateandtime);
        btn = findViewById(R.id.location_btn);
        title_report = findViewById(R.id.title_report);
        takePhoto = findViewById(R.id.takePhoto);
        img = findViewById(R.id.image);

        mNotificationHelper = new NotificationHelper(this);

        title_dateandtime.setInputType(InputType.TYPE_NULL);

        database_helper = new NotesDatabaseHelper(this);

        title_dateandtime.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showDateTimeDialog(title_dateandtime);
                closeKeyboard();
            }
        });

        fusedLocationProviderClient = LocationServices.getFusedLocationProviderClient(this);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.M){
                    if(getApplicationContext().checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)
                    == PackageManager.PERMISSION_GRANTED){

                        fusedLocationProviderClient.getLastLocation()
                                .addOnSuccessListener(new OnSuccessListener<Location>() {
                                    @Override
                                    public void onSuccess(Location location) {
                                        if(location != null)    {
                                            try {
                                                Geocoder geocoder = new Geocoder(getApplicationContext(), Locale.getDefault());
                                                List<Address> addresses = geocoder.getFromLocation(location.getLatitude(), location.getLongitude(), 1);
                                                title_location.setText(addresses.get(0).getAddressLine(0));

                                            } catch (Exception e) {
                                            }
//                                            title_location.setText(lat + "," + longt);
                                            Toast.makeText(AddActivity.this,"Success",Toast.LENGTH_SHORT);

                                        }else {
                                            title_location.setText("No Location Available");
                                        }

                                    }
                                });

                    }else{
                        requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION},1);
                    }
                }
            }
        });

        takePhoto.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                if(intent.resolveActivity(getPackageManager()) != null){
                    startActivityForResult(intent, 51);
                }
            }
        });

    }

    private void closeKeyboard(){
        InputMethodManager imm = (InputMethodManager)getSystemService(Context.INPUT_METHOD_SERVICE);
    }

    private void showDateTimeDialog(final EditText title_dateandtime) {
        final Calendar calendar=Calendar.getInstance();
        DatePickerDialog.OnDateSetListener dateSetListener=new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                calendar.set(Calendar.YEAR,year);
                calendar.set(Calendar.MONTH,month);
                calendar.set(Calendar.DAY_OF_MONTH,dayOfMonth);

                TimePickerDialog.OnTimeSetListener timeSetListener=new TimePickerDialog.OnTimeSetListener() {
                    @Override
                    public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
                        calendar.set(Calendar.HOUR_OF_DAY,hourOfDay);
                        calendar.set(Calendar.MINUTE,minute);

                        SimpleDateFormat simpleDateFormat=new SimpleDateFormat("yy-MM-dd HH:mm");

                        title_dateandtime.setText(simpleDateFormat.format(calendar.getTime()));
                    }
                };

                new TimePickerDialog(AddActivity.this,timeSetListener,
                        calendar.get(Calendar.HOUR_OF_DAY),calendar.get(Calendar.MINUTE),false).show();
            }
        };

        new DatePickerDialog(AddActivity.this,dateSetListener,
                calendar.get(Calendar.YEAR),calendar.get(Calendar.MONTH),calendar.get(Calendar.DAY_OF_MONTH)).show();

    }
    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
            switch (item.getItemId()) {
                case R.id.save_activity_menu:
                    save_note();
                    break;
                case android.R.id.home:
                    onBackPressed();
                    break;
                case R.id.location_btn:
                    Intent add_note_intent = new Intent(AddActivity.this, MapsActivity.class);
                    startActivity(add_note_intent);
                    break;
            }
            return super.onOptionsItemSelected(item);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.add_activity_menu,menu);
        return super.onCreateOptionsMenu(menu);
    }

    private void save_note(){
        if( title_activity.length() == 0 && title_location.length() == 0 && title_dateandtime.length() == 0 && title_report.length() == 0){
            title_activity.setError("Please Enter Activity");
            title_location.setError("Please Choose Location");
            title_dateandtime.setError("Please Choose Date/Time");
            title_report.setError("Please Write Report");
        }else if(title_activity.length() == 0){
            title_activity.setError("Please Enter Activity");
        }else if( title_location.length() == 0){
            title_location.setError("Please Choose Location");
        }else if( title_dateandtime.length() == 0){
            title_dateandtime.setError("Please Choose Date/Time");
        }else if( title_report.length() == 0){
            title_report.setError("Please Write Report");
        }else {
            String activity = title_activity.getText().toString();
            String report = title_report.getText().toString();
            String location = title_location.getText().toString();
            String dateandtime = title_dateandtime.getText().toString();
            byte[] picbyte;
            if(pic == null)
                picbyte = null;
            else
                picbyte = image2array(pic);

            database_helper.addActivity(activity, report, location, dateandtime, picbyte);

            sendOnChannel1(title_activity.getText().toString(),title_dateandtime.getText().toString());
        }
    }

    public void sendOnChannel1(String activity,String dateandtime){
        NotificationCompat.Builder nb = mNotificationHelper.getChannel1Notification(activity,dateandtime);
        mNotificationHelper.getManager().notify(1,nb.build());
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        switch (requestCode){
            case 51:
                //            if (requestCode == Activity.RESULT_OK){
                pic = (Bitmap) data.getExtras().get("data"); //converting into bitmap
                if(pic != null){
                    img.setImageBitmap(pic); // put the bitmap into our image
                }else{
                    Toast.makeText(
                            this,
                            "Bitmap is NULL",
                            Toast.LENGTH_SHORT
                    ).show();
                }
                break;
        }
    }

    protected static byte[] image2array(Bitmap bitmap){
        ByteArrayOutputStream stream = new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.JPEG, 100, stream);
        return stream.toByteArray();
    }
}
