package com.mykid;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NotificationCompat;

import android.Manifest;
import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.location.Location;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.text.InputType;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TimePicker;
import android.widget.Toast;

import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.tasks.OnSuccessListener;
import com.mykid.RoomHelper.NotesDatabaseHelper;
import com.mykid.RoomHelper.NotesPojo;
import com.mykid.RoomHelper.NotificationHelper;

import java.io.ByteArrayOutputStream;
import java.text.SimpleDateFormat;
import java.util.Calendar;

public class UpdateActivity extends AppCompatActivity {

    EditText title_activity,title_location,title_dateandtime,title_report;
    NotesPojo notesPojo;
    Button btn, btnTakePhoto;
    Bitmap pic;
    ImageView imgView;

    private FusedLocationProviderClient fusedLocationProviderClient;
    private NotificationHelper mNotificationHelper;
    NotesDatabaseHelper database_helper;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update);
        getSupportActionBar().setTitle("Update Activity");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);

        title_activity = findViewById(R.id.title_activity);
        title_location = findViewById(R.id.title_location);
        title_dateandtime = findViewById(R.id.title_dateandtime);
        title_report = findViewById(R.id.title_report);
        btn = findViewById(R.id.location_btn);
        btnTakePhoto = findViewById(R.id.takePhoto);
        imgView = findViewById(R.id.image);
        mNotificationHelper = new NotificationHelper(this);
        title_dateandtime.setInputType(InputType.TYPE_NULL);
        title_dateandtime.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showDateTimeDialog(title_dateandtime);
                closeKeyboard();
            }
        });

        database_helper = new NotesDatabaseHelper(this);
        notesPojo = (NotesPojo)getIntent().getSerializableExtra("activity_tables");

        setData();
        fusedLocationProviderClient = LocationServices.getFusedLocationProviderClient(this);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.M){
                    if(getApplicationContext().checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)
                            == PackageManager.PERMISSION_GRANTED){

                        fusedLocationProviderClient.getLastLocation()
                                .addOnSuccessListener(new OnSuccessListener<Location>() {
                                    @Override
                                    public void onSuccess(Location location) {
                                        if(location != null){
                                            Double lat = location.getLatitude();
                                            Double longt = location.getLongitude();

                                            title_location.setText(lat + "," + longt);
                                            Toast.makeText(UpdateActivity.this,"Success",Toast.LENGTH_SHORT);
                                        }

                                    }
                                });

                    }else{
                        requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION},1);
                    }
                }
            }
        });

        btnTakePhoto.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                if(intent.resolveActivity(getPackageManager()) != null){
                    startActivityForResult(intent, 51);
                }
            }
        });
    }

    private void closeKeyboard(){
        InputMethodManager imm = (InputMethodManager)getSystemService(Context.INPUT_METHOD_SERVICE);
    }

    private void showDateTimeDialog(final EditText title_dateandtime) {
        final Calendar calendar=Calendar.getInstance();
        DatePickerDialog.OnDateSetListener dateSetListener=new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                calendar.set(Calendar.YEAR,year);
                calendar.set(Calendar.MONTH,month);
                calendar.set(Calendar.DAY_OF_MONTH,dayOfMonth);

                TimePickerDialog.OnTimeSetListener timeSetListener=new TimePickerDialog.OnTimeSetListener() {
                    @Override
                    public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
                        calendar.set(Calendar.HOUR_OF_DAY,hourOfDay);
                        calendar.set(Calendar.MINUTE,minute);

                        SimpleDateFormat simpleDateFormat=new SimpleDateFormat("yy-MM-dd HH:mm");

                        title_dateandtime.setText(simpleDateFormat.format(calendar.getTime()));
                    }
                };

                new TimePickerDialog(UpdateActivity.this,timeSetListener,
                        calendar.get(Calendar.HOUR_OF_DAY),calendar.get(Calendar.MINUTE),false).show();
            }
        };

        new DatePickerDialog(UpdateActivity.this,dateSetListener,
                calendar.get(Calendar.YEAR),calendar.get(Calendar.MONTH),calendar.get(Calendar.DAY_OF_MONTH)).show();

    }

    private  void setData(){
        title_activity.setText(notesPojo.getTitle());
        title_location.setText(notesPojo.getLocation());
        title_dateandtime.setText(notesPojo.getDateandtime());
        title_report.setText(notesPojo.getDescription());
        try {
            imgView.setImageBitmap(array2image(notesPojo.getImage()));
        }
        catch (Exception e){
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.update_activity_menu,menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch(item.getItemId()){
            case R.id.save_activity_menu:
                save_note();
                break;
            case R.id.delete:
                deleteActivityDialog();
                break;
            case android.R.id.home:
                onBackPressed();
                break;
        }
        return super.onOptionsItemSelected(item);
    }

    private void save_note(){
        if( title_activity.length() == 0 && title_location.length() == 0 && title_dateandtime.length() == 0 && title_report.length() == 0){
            title_activity.setError("Please Enter Activity");
            title_location.setError("Please Choose Location");
            title_dateandtime.setError("Please Choose Date/Time");
            title_report.setError("Please Write Report");
        }else if(title_activity.length() == 0){
            title_activity.setError("Please Enter Activity");
        }else if( title_location.length() == 0){
            title_location.setError("Please Choose Location");
        }else if( title_dateandtime.length() == 0){
            title_dateandtime.setError("Please Choose Date/Time");
        }else if( title_report.length() == 0){
            title_report.setError("Please Write Report");
        }else {
            String activity = title_activity.getText().toString();
            String report = title_report.getText().toString();
            String location = title_location.getText().toString();
            String dateandtime = title_dateandtime.getText().toString();
            byte picbyte[];
            if(pic == null)
                picbyte = null;
            else
                picbyte = image2array(pic);
            database_helper.updateActivity(notesPojo, activity, report, location, dateandtime, picbyte);
            sendOnChannel2(title_activity.getText().toString(),title_dateandtime.getText().toString());
        }
    }
    public void sendOnChannel2(String activity,String dateandtime){
        NotificationCompat.Builder nb = mNotificationHelper.getChannel2Notification(activity,dateandtime);
        mNotificationHelper.getManager().notify(2,nb.build());
    }

    private AlertDialog deleteActivityDialog(){
        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("Are you sure you want to delete ?")
                .setMessage(notesPojo.getTitle())
                .setPositiveButton("Delete", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        database_helper.deleteActivity(notesPojo);
                        dialog.dismiss();
                    }
                }).setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                }).show();
        return dialog;
    }

    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        switch (requestCode){
            case 51:
                //            if (requestCode == Activity.RESULT_OK){
                pic = (Bitmap) data.getExtras().get("data"); //converting into bitmap
                if(pic != null){
                    imgView.setImageBitmap(pic); // put the bitmap into our image
                }else{
                    Toast.makeText(
                            this,
                            "Bitmap is NULL",
                            Toast.LENGTH_SHORT
                    ).show();
                }
                break;
        }
    }

    protected static byte[] image2array(Bitmap bitmap){
        ByteArrayOutputStream stream = new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.JPEG, 100, stream);
        return stream.toByteArray();
    }

    protected static Bitmap array2image(byte [] array){
        return BitmapFactory.decodeByteArray(array, 0, array.length); // decode the byte array and convert bitmap and send it back
    }
}